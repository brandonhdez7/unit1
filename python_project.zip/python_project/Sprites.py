import pygame
from pygame.sprite import Sprite 
from Settings import *
from random import randint

class Char(Sprite):
    def __init__(self):
        super(Char, self).__init__()
        self.x = 64
        self.y = 64
        self.speed = 5
        self.should_move_down = False
        self.should_move_up = False
        self.should_move_left = False
        self.should_move_right = False
        self.rect = pygame.Rect(0,0,32,32)
        self.rect.centerx = self.x 
        self.rect.top = self.y 
        self.image_face = []
        self.image_face.append(pygame.image.load("bunny_down_01.png"))
        self.image_face.append(pygame.image.load("bunny_down_02.png"))
        self.image_back = []
        self.image_back.append(pygame.image.load("bunny_up_01.png"))
        self.image_back.append(pygame.image.load("bunny_up_02.png"))
        self.image_right = []
        self.image_right.append(pygame.image.load("bunny_right_01.png"))
        self.image_right.append(pygame.image.load("bunny_right_02.png"))
        self.image_left = []
        self.image_left.append(pygame.image.load("bunny_left_01.png"))
        self.image_left.append(pygame.image.load("bunny_left_02.png"))
        self.bunny = [self.image_face,self.image_back,self.image_left,self.image_right]
        self.img = pygame.image.load("bunny_down_01.png")
        self.cur_image = 0
       
    def shouldMove(self, direction, start = True):
        if direction == "right":
            self.image_right
            self.should_move_right = start 
        if direction == "left":
            self.image_left
            self.should_move_left = start 
        if direction == "up":
            self.image_back
            self.should_move_up = start
        if direction == "down":
            self.image_face
            self.should_move_down = start      

    def draw_me(self,w,h):
        if(self.should_move_right):
            if(self.x <= WIDTH - 30):
                self.x += self.speed
        elif(self.should_move_left):
            if(self.x >= 30):
                self.x -= self.speed
        if(self.should_move_down):
            if(self.y <= HEIGHT - 30):
                self.y += self.speed
        elif self.should_move_up:
            if(self.y >= 30):
                self.y -= self.speed  
    
    
    
   