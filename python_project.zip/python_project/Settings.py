
width= 800  
height = 800  


tileWidth = 32
tileHeight = 32
gridWidth = width / tileWidth
gridHeight = height / tileHeight




