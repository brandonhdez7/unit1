<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.1" name="maze 32x32(#165447721)" tilewidth="32" tileheight="32" tilecount="324" columns="18">
 <image source="../../Downloads/maze 32x32(#165447721).png" width="576" height="576"/>
</tileset>
