<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.1" name="ProjectUtumno_full" tilewidth="32" tileheight="32" tilecount="6080" columns="64">
 <image source="game_art_packs/ProjectUtumno_full.png" width="2048" height="3040"/>
</tileset>
