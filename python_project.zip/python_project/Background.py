import pygame
import pytmx

class TiledMap():
    def __init__(self):
        self.game_map = pytmx.load.pygame("maze_game_map.tmx", pixel_alpha = True)
        self.map_width = self.game_map.tilewidth * self.game_map.width 
        self.map_height = self.gameMap.tileheight * self.game_map.map_height

    def render(self, surface):
        for layer in self.game_map.visible_layers:
            if isinstance(layer, pytmx.TiledTileLayer):
                for x, y, gid in layer:
                    tile = self.game_map.get_tile_image_by_gid(gid)
                    if tile:
                        surface.blit(tile, (x * self.game_map.tilewidth, y * self.game_map.tileheight))
                    
    def make_map(self):
        mapSurface = pygame.Surface((self.map_width, self.map_height))
        self.render(mapSurface)
        return mapSurface

class Display():
    def __init__(self):
        self.display_running = True
        self.display_window = pygame.display.set_mode((800,800))

    def update(self):
        self.map = TiledMap()
        self.map_img = self.map.make.map()
        self.map_rect = self.map_img.get_rect()

    def loadMap(self):
        self.map = TiledMap()
        self.map_img = self.map.make_map()
        self.map_rect = self.map_img.get_rect()

    def displayLoop(self):
        self.update()
        self.loadMap()

