

import pygame
import pytmx 
from pytmx.util_pygame import load_pygame 
from Sprites import Char
pygame.init()
# screen_size = (800, 800)
pygame_screen = pygame.display.set_mode((800,800), 0, 32)

tmxdata = load_pygame("maze_game_map.tmx")



player = Char()

# myWindow = pygame.display.set_mode((800,600), 0, 32)
pygame.display.set_caption("Maze Game")
pygame.key.set_repeat(500, 100)

gameMap = pytmx.TiledMap("maze_game_map.tmx")

player_image = pygame.image.load("bunny_down_01.png")

class TiledMap():
    def __init__(self):
        self.game_map = pytmx.load.pygame("maze_game_map.tmx", pixel_alpha = True)
        self.map_width = self.game_map.tilewidth * self.game_map.width 
        self.map_height = self.gameMap.tileheight * self.game_map.map_height

    def render(self, surface):
        for layer in self.game_map.visible_layers:
            if isinstance(layer, pytmx.TiledTileLayer):
                for x, y, gid in layer:
                    tile = self.game_map.get_tile_image_by_gid(gid)
                    if tile:
                        surface.blit(tile, (x * self.game_map.tilewidth, y * self.game_map.tileheight))
                    
    def make_map(self):
        mapSurface = pygame.Surface((self.map_width, self.map_height))
        self.render(mapSurface)
        return mapSurface

class Display():
    def __init__(self):
        self.display_running = True
        self.display_window = pygame.display.set_mode((800,800))

    def update(self):
        self.map = TiledMap()
        self.map_img = self.map.make.map()
        self.map_rect = self.map_img.get_rect()

    def loadMap(self):
        self.map = TiledMap()
        self.map_img = self.map.make_map()
        self.map_rect = self.map_img.get_rect()

    def displayLoop(self):
        self.update()
        self.loadMap()

game_on = True

while game_on: 
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            game_on = False 
        elif event.type == pygame.KEYDOWN:
                print(event.key) 
                if event.key == 275: 
                    player.shouldMove("right")
                elif event.key == 276: 
                    player.shouldMove("left")
                if event.key == 273: 
                    player.shouldMove("up")
                elif event.key == 274: 
                    player.shouldMove("down")
                
        elif event.type == pygame.KEYUP:
            print(event.key) 
            if event.key == 275: 
                player.shouldMove("right", False)
            elif event.key == 276: #left arrow
                player.shouldMove("left", False)
            if event.key == 273: #up arrow
                player.shouldMove("up", False)
            elif event.key == 274: #down arrow
                player.shouldMove("down", False)   
 
    for layer in gameMap.visible_layers:
            for x, y, gid, in layer:
                tile = (gameMap.get_tile_image_by_gid(gid))
                
                pygame_screen.blit(tile, (x * gameMap.tilewidth, y * gameMap.tileheight))
    
    player.draw_me(480,480)
    player.shouldMove(player.x, player.y)
    pygame_screen.blit(player_image, [player.x, player.y])
    
    pygame.display.flip()  

